package cl.duoc.miapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
